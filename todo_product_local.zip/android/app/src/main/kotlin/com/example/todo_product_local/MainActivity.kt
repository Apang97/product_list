package com.example.todo_product_local

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
